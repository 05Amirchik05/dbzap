/*
  # Initial Schema Setup for DB ZAP

  1. New Tables
    - `profiles`
      - User profile information
      - Stores name, phone, delivery addresses
    - `garages`
      - User's saved vehicles
    - `orders`
      - Order history and status
    - `order_items`
      - Individual items in orders
    - `favorites`
      - Saved parts
    - `price_history`
      - Track price changes
    - `user_balance`
      - Track user account balance
    
  2. Security
    - Enable RLS on all tables
    - Add policies for user data access
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  email text UNIQUE NOT NULL,
  full_name text,
  phone_primary text,
  phone_secondary text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  price_markup_percentage integer DEFAULT 0,
  show_markup_prices boolean DEFAULT false,
  pricing_level text DEFAULT 'standard'
);

-- Delivery addresses
CREATE TABLE IF NOT EXISTS delivery_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  address text NOT NULL,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Garage (saved vehicles)
CREATE TABLE IF NOT EXISTS garages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  vin text NOT NULL,
  nickname text,
  make text,
  model text,
  year integer,
  created_at timestamptz DEFAULT now()
);

-- Orders
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id),
  status text NOT NULL DEFAULT 'pending',
  delivery_type text NOT NULL,
  delivery_address text,
  total_amount decimal(10,2) NOT NULL,
  comment text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Order items
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  part_number text NOT NULL,
  quantity integer NOT NULL,
  price_per_unit decimal(10,2) NOT NULL,
  delivery_days integer,
  created_at timestamptz DEFAULT now()
);

-- Favorites
CREATE TABLE IF NOT EXISTS favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  part_number text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Price history
CREATE TABLE IF NOT EXISTS price_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  part_number text NOT NULL,
  old_price decimal(10,2) NOT NULL,
  new_price decimal(10,2) NOT NULL,
  old_delivery_days integer,
  new_delivery_days integer,
  created_at timestamptz DEFAULT now()
);

-- User balance
CREATE TABLE IF NOT EXISTS user_balance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  amount decimal(10,2) NOT NULL,
  transaction_type text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE garages ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE price_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_balance ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can view own addresses"
  ON delivery_addresses FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "Users can manage own addresses"
  ON delivery_addresses FOR ALL
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "Users can view own garage"
  ON garages FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "Users can manage own garage"
  ON garages FOR ALL
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "Users can view own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (order_id IN (
    SELECT id FROM orders WHERE profile_id = auth.uid()
  ));

CREATE POLICY "Users can view own favorites"
  ON favorites FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "Users can manage own favorites"
  ON favorites FOR ALL
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "Users can view price history"
  ON price_history FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view own balance"
  ON user_balance FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid());