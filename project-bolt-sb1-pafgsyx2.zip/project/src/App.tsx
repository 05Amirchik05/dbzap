import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Github, Mail, Phone, MapPin } from 'lucide-react';
import { PartsSearch } from './components/PartsSearch';
import { VehicleLookup } from './components/VehicleLookup';
import { ExpertConsultation } from './components/ExpertConsultation';
import { ThemeToggle } from './components/ThemeToggle';
import { PrivacyPolicy } from './components/PrivacyPolicy';
import { AuthProvider } from './components/auth/AuthProvider';
import { AuthModal } from './components/auth/AuthModal';
import { ProfileMenu } from './components/profile/ProfileMenu';
import { GarageView } from './components/garage/GarageView';
import { CartView } from './components/cart/CartView';
import { FavoritesView } from './components/favorites/FavoritesView';
import { OrdersView } from './components/orders/OrdersView';
import { BalanceView } from './components/balance/BalanceView';
import { PriceSettings } from './components/settings/PriceSettings';

function App() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  return (
    <AuthProvider>
      <Router>
        <div className={`min-h-screen theme-transition ${theme === 'light' ? 'bg-white text-black' : 'bg-black text-white'}`}>
          <div className="p-8 md:p-16 flex flex-col min-h-screen">
            <header className={`mb-20 ${isLoaded ? 'animate-slide-up' : 'opacity-0'}`}>
              <nav className="flex justify-between items-center">
                <div className="text-xl font-light">DB ZAP</div>
                <div className="flex gap-6 items-center">
                  <a href="tel:+79807380523" className="link-hover flex items-center gap-2">
                    <Phone className="w-5 h-5" />
                    <span className="hidden md:inline">+7 (980) 738-05-23</span>
                  </a>
                  <a href="mailto:dbzap@mail.ru" className="link-hover flex items-center gap-2">
                    <Mail className="w-5 h-5" />
                    <span className="hidden md:inline">dbzap@mail.ru</span>
                  </a>
                  <a href="https://maps.google.com/?q=Иваново,ул.Минская,132ж" 
                     target="_blank" 
                     rel="noopener noreferrer" 
                     className="link-hover flex items-center gap-2">
                    <MapPin className="w-5 h-5" />
                    <span className="hidden md:inline">г. Иваново, ул. Минская, 132 ж</span>
                  </a>
                  <button
                    onClick={() => setIsAuthModalOpen(true)}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    Войти
                  </button>
                </div>
              </nav>
            </header>

            <main className="flex-grow">
              <Routes>
                <Route path="/" element={
                  <div className={`max-w-4xl mx-auto space-y-12 ${isLoaded ? 'animate-slide-up' : 'opacity-0'}`}>
                    <div className="text-center">
                      <h1 className="text-4xl md:text-5xl font-light leading-tight mb-8">
                        Поиск автозапчастей с помощью ИИ
                      </h1>
                      <p className={`text-lg mb-12 ${theme === 'light' ? 'text-gray-600' : 'text-gray-400'}`}>
                        Найдите необходимые запчасти для вашего автомобиля с помощью искусственного интеллекта
                        или воспользуйтесь помощью наших экспертов.
                      </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-8">
                      <VehicleLookup />
                      <PartsSearch />
                    </div>

                    <ExpertConsultation />
                  </div>
                } />
                <Route path="/privacy" element={<PrivacyPolicy />} />
                <Route path="/garage" element={<GarageView />} />
                <Route path="/cart" element={<CartView />} />
                <Route path="/favorites" element={<FavoritesView />} />
                <Route path="/orders" element={<OrdersView />} />
                <Route path="/balance" element={<BalanceView />} />
                <Route path="/settings/prices" element={<PriceSettings />} />
              </Routes>
            </main>

            <footer className={`mt-20 ${theme === 'light' ? 'text-gray-600' : 'text-gray-500'} ${isLoaded ? 'animate-slide-up' : 'opacity-0'}`}>
              <div className="text-center">
                <p>© 2024 DB ZAP — г. Иваново, ул. Минская, 132 ж</p>
                <div className="mt-2 space-x-4">
                  <a href="tel:+79807380523" className="hover:text-current transition-colors">+7 (980) 738-05-23</a>
                  <a href="mailto:dbzap@mail.ru" className="hover:text-current transition-colors">dbzap@mail.ru</a>
                  <a href="/privacy" className="hover:text-current transition-colors">Политика конфиденциальности</a>
                </div>
              </div>
            </footer>
          </div>

          <ThemeToggle theme={theme} onToggle={toggleTheme} />
          <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;