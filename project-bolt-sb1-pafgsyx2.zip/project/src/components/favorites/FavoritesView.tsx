import React, { useState, useEffect } from 'react';
import { Heart, ShoppingCart, Trash2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../auth/AuthProvider';

interface FavoriteItem {
  id: string;
  part_number: string;
  name: string;
  price: number;
  availability: string;
}

export function FavoritesView() {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);

  useEffect(() => {
    if (user) {
      loadFavorites();
    }
  }, [user]);

  const loadFavorites = async () => {
    const { data, error } = await supabase
      .from('favorites')
      .select('*')
      .eq('profile_id', user?.id);

    if (error) {
      console.error('Error loading favorites:', error);
    } else {
      setFavorites(data || []);
    }
  };

  const removeFromFavorites = async (id: string) => {
    const { error } = await supabase
      .from('favorites')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Error removing from favorites:', error);
    } else {
      loadFavorites();
    }
  };

  const addToCart = async (item: FavoriteItem) => {
    const { error } = await supabase
      .from('cart_items')
      .insert([
        {
          profile_id: user?.id,
          part_number: item.part_number,
          name: item.name,
          price: item.price,
          quantity: 1
        }
      ]);

    if (error) {
      console.error('Error adding to cart:', error);
    } else {
      // Optionally show success message
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex items-center gap-3 mb-8">
        <Heart className="w-6 h-6 text-red-500" />
        <h1 className="text-2xl font-light">Избранное</h1>
      </div>

      <div className="grid gap-6">
        {favorites.map((item) => (
          <div
            key={item.id}
            className="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6"
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-medium mb-2">{item.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 part-number">
                  {item.part_number}
                </p>
                <p className="mt-2 text-lg font-medium">
                  {item.price.toLocaleString('ru-RU')} ₽
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {item.availability}
                </p>
              </div>
              <div className="flex gap-4">
                <button
                  onClick={() => addToCart(item)}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span>В корзину</span>
                </button>
                <button
                  onClick={() => removeFromFavorites(item.id)}
                  className="text-red-500 hover:text-red-700"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        ))}

        {favorites.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            <Heart className="w-12 h-12 mx-auto mb-4 stroke-1" />
            <p>В избранном пока ничего нет</p>
          </div>
        )}
      </div>
    </div>
  );
}