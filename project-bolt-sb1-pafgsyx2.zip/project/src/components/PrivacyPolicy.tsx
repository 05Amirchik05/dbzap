import React from 'react';

export function PrivacyPolicy() {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <h1 className="text-3xl font-light mb-8">Политика конфиденциальности</h1>
      <div className="prose prose-invert">
        {/* Content will be added later */}
        <p>Содержание будет добавлено позже.</p>
      </div>
    </div>
  );
}