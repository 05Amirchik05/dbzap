import React, { useState, useEffect } from 'react';
import { Wallet, ArrowUpRight, ArrowDownRight, Download } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../auth/AuthProvider';

interface Transaction {
  id: string;
  amount: number;
  transaction_type: 'deposit' | 'withdrawal' | 'refund';
  description: string;
  created_at: string;
}

export function BalanceView() {
  const { user } = useAuth();
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    if (user) {
      loadBalance();
      loadTransactions();
    }
  }, [user]);

  const loadBalance = async () => {
    const { data, error } = await supabase
      .from('user_balance')
      .select('amount')
      .eq('profile_id', user?.id)
      .order('created_at', { ascending: false })
      .limit(1);

    if (error) {
      console.error('Error loading balance:', error);
    } else if (data && data.length > 0) {
      setBalance(data[0].amount);
    }
  };

  const loadTransactions = async () => {
    const { data, error } = await supabase
      .from('user_balance')
      .select('*')
      .eq('profile_id', user?.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading transactions:', error);
    } else {
      setTransactions(data || []);
    }
  };

  const downloadStatement = async () => {
    // Implement statement download logic
    console.log('Downloading statement');
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit':
        return <ArrowUpRight className="w-5 h-5 text-green-500" />;
      case 'withdrawal':
        return <ArrowDownRight className="w-5 h-5 text-red-500" />;
      case 'refund':
        return <ArrowUpRight className="w-5 h-5 text-blue-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-3">
          <Wallet className="w-6 h-6" />
          <h1 className="text-2xl font-light">Баланс</h1>
        </div>
        <button
          onClick={downloadStatement}
          className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
        >
          <Download className="w-5 h-5" />
          <span>Выписка</span>
        </button>
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 mb-8">
        <p className="text-sm text-gray-500 dark:text-gray-400">Текущий баланс</p>
        <p className="text-3xl font-medium mt-1">
          {balance.toLocaleString('ru-RU')} ₽
        </p>
      </div>

      <div className="space-y-4">
        {transactions.map((transaction) => (
          <div
            key={transaction.id}
            className="bg-white dark:bg-gray-900 rounded-lg shadow p-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              {getTransactionIcon(transaction.transaction_type)}
              <div>
                <p className="font-medium">
                  {transaction.description || 'Операция'}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {new Date(transaction.created_at).toLocaleDateString('ru-RU')}
                </p>
              </div>
            </div>
            <p className={`font-medium ${
              transaction.transaction_type === 'withdrawal'
                ? 'text-red-500'
                : 'text-green-500'
            }`}>
              {transaction.transaction_type === 'withdrawal' ? '-' : '+'}
              {Math.abs(transaction.amount).toLocaleString('ru-RU')} ₽
            </p>
          </div>
        ))}

        {transactions.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            <Wallet className="w-12 h-12 mx-auto mb-4 stroke-1" />
            <p>История операций пуста</p>
          </div>
        )}
      </div>
    </div>
  );
}