import React, { useState } from 'react';
import { Search, Loader2 } from 'lucide-react';
import { searchParts } from '../lib/ai';

interface SearchResult {
  partName: string;
  description: string;
  compatibility: string;
  price: string;
  availability: string;
}

export function PartsSearch() {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [error, setError] = useState('');

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setError('');

    try {
      const searchResults = await searchParts(query);
      setResults(searchResults);
    } catch (err) {
      setError('Failed to search parts. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <form onSubmit={handleSearch} className="mb-8">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Describe the part you're looking for..."
            className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 pl-12 text-white placeholder-gray-500 focus:outline-none focus:border-gray-700"
          />
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 w-5 h-5" />
          {isLoading && (
            <Loader2 className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 w-5 h-5 animate-spin" />
          )}
        </div>
      </form>

      {error && (
        <div className="text-red-500 mb-4">{error}</div>
      )}

      <div className="space-y-4">
        {results.map((result, index) => (
          <div
            key={index}
            className="bg-gray-900 border border-gray-800 rounded-lg p-4 hover:border-gray-700 transition-colors"
          >
            <h3 className="text-lg font-medium text-white mb-2">{result.partName}</h3>
            <p className="text-gray-400 mb-2">{result.description}</p>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Compatibility:</span>
                <span className="text-gray-300 ml-2">{result.compatibility}</span>
              </div>
              <div>
                <span className="text-gray-500">Price:</span>
                <span className="text-gray-300 ml-2">{result.price}</span>
              </div>
              <div>
                <span className="text-gray-500">Availability:</span>
                <span className="text-gray-300 ml-2">{result.availability}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}