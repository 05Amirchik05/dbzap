import React from 'react';
import { TrendingUp, TrendingDown, Clock } from 'lucide-react';

interface PriceChange {
  oldPrice: number;
  newPrice: number;
  oldDelivery: number;
  newDelivery: number;
}

export function PriceChangeIndicator({ changes }: { changes: PriceChange }) {
  const priceChanged = changes.oldPrice !== changes.newPrice;
  const deliveryChanged = changes.oldDelivery !== changes.newDelivery;

  return (
    <div className="text-sm space-y-2">
      {priceChanged && (
        <div className="flex items-center gap-2">
          {changes.newPrice < changes.oldPrice ? (
            <TrendingDown className="w-4 h-4 text-green-500" />
          ) : (
            <TrendingUp className="w-4 h-4 text-red-500" />
          )}
          <span>
            Цена изменилась: {changes.oldPrice} ₽ → {changes.newPrice} ₽
          </span>
        </div>
      )}
      {deliveryChanged && (
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-blue-500" />
          <span>
            Срок доставки: {changes.oldDelivery} дн. → {changes.newDelivery} дн.
          </span>
        </div>
      )}
    </div>
  );
}