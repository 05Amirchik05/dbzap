import React, { useState, useEffect } from 'react';
import { Percent, Eye, EyeOff } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../auth/AuthProvider';

interface PriceSettings {
  markup_percentage: number;
  show_markup_prices: boolean;
}

export function PriceSettings() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<PriceSettings>({
    markup_percentage: 0,
    show_markup_prices: false
  });

  useEffect(() => {
    if (user) {
      loadSettings();
    }
  }, [user]);

  const loadSettings = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select('price_markup_percentage, show_markup_prices')
      .eq('id', user?.id)
      .single();

    if (error) {
      console.error('Error loading price settings:', error);
    } else if (data) {
      setSettings({
        markup_percentage: data.price_markup_percentage || 0,
        show_markup_prices: data.show_markup_prices || false
      });
    }
  };

  const updateSettings = async (updates: Partial<PriceSettings>) => {
    const { error } = await supabase
      .from('profiles')
      .update({
        price_markup_percentage: updates.markup_percentage !== undefined
          ? updates.markup_percentage
          : settings.markup_percentage,
        show_markup_prices: updates.show_markup_prices !== undefined
          ? updates.show_markup_prices
          : settings.show_markup_prices
      })
      .eq('id', user?.id);

    if (error) {
      console.error('Error updating price settings:', error);
    } else {
      setSettings(prev => ({ ...prev, ...updates }));
    }
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-3 mb-6">
        <Percent className="w-6 h-6 text-blue-500" />
        <h2 className="text-xl font-light">Настройки цен</h2>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Наценка (%)
          </label>
          <input
            type="number"
            min="0"
            max="100"
            value={settings.markup_percentage}
            onChange={(e) => updateSettings({ markup_percentage: parseInt(e.target.value) || 0 })}
            className="w-full px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700"
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium">Показывать цены с наценкой</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              При включении все цены будут отображаться с учётом наценки
            </p>
          </div>
          <button
            onClick={() => updateSettings({ show_markup_prices: !settings.show_markup_prices })}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
          >
            {settings.show_markup_prices ? (
              <>
                <EyeOff className="w-5 h-5" />
                <span>Скрыть</span>
              </>
            ) : (
              <>
                <Eye className="w-5 h-5" />
                <span>Показать</span>
              </>
            )}
          </button>
        </div>

        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Пример расчёта:
          </p>
          <div className="mt-2 space-y-1">
            <p>Базовая цена: 1000 ₽</p>
            <p>Наценка {settings.markup_percentage}%: {10 * settings.markup_percentage} ₽</p>
            <p className="font-medium">
              Итоговая цена: {1000 + (10 * settings.markup_percentage)} ₽
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}