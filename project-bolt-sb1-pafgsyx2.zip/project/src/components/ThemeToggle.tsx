import React from 'react';
import { Sun, Moon } from 'lucide-react';

export function ThemeToggle({ theme, onToggle }: { theme: 'light' | 'dark', onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      className="fixed bottom-8 right-8 p-3 rounded-full bg-gray-800 dark:bg-white text-white dark:text-gray-800 shadow-lg transition-all hover:scale-110"
      aria-label="Toggle theme"
    >
      {theme === 'light' ? <Moon className="w-6 h-6" /> : <Sun className="w-6 h-6" />}
    </button>
  );
}