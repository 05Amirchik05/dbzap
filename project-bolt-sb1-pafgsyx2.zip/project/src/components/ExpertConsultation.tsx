import React, { useState } from 'react';
import { Send } from 'lucide-react';

interface ConsultationForm {
  vin: string;
  partsList: string;
  phone: string;
  name: string;
}

export function ExpertConsultation() {
  const [form, setForm] = useState<ConsultationForm>({
    vin: '',
    partsList: '',
    phone: '',
    name: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          access_key: 'YOUR-WEB3FORMS-KEY', // Replace with your Web3Forms key
          subject: 'Новая заявка на подбор запчастей',
          from_name: 'DB ZAP Website',
          to: 'dbzap@mail.ru',
          message: `
            Новая заявка на подбор запчастей:
            
            Имя клиента: ${form.name}
            Телефон: ${form.phone}
            VIN код: ${form.vin}
            Список запчастей: ${form.partsList}
          `
        })
      });
      
      if (response.ok) {
        alert('Заявка успешно отправлена!');
        setForm({ vin: '', partsList: '', phone: '', name: '' });
      }
    } catch (error) {
      console.error('Error sending form:', error);
      alert('Ошибка при отправке формы. Пожалуйста, попробуйте позже.');
    }
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
      <h2 className="text-xl font-light mb-4">Подбор запчастей экспертом DB ZAP</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <input
            type="text"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Ваше имя"
            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gray-600"
            required
          />
        </div>
        <div>
          <input
            type="tel"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="Номер телефона"
            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gray-600"
            required
          />
        </div>
        <div>
          <input
            type="text"
            value={form.vin}
            onChange={(e) => setForm({ ...form, vin: e.target.value })}
            placeholder="VIN код автомобиля"
            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gray-600"
            required
          />
        </div>
        <div>
          <textarea
            value={form.partsList}
            onChange={(e) => setForm({ ...form, partsList: e.target.value })}
            placeholder="Список необходимых запчастей"
            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gray-600 min-h-[100px]"
            required
          />
        </div>
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          <Send className="w-5 h-5" />
          Отправить заявку
        </button>
      </form>
    </div>
  );
}