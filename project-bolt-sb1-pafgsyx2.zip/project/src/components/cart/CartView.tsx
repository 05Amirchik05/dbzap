import React, { useState, useEffect } from 'react';
import { Folder, Plus, X, ShoppingCart } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { PriceChangeIndicator } from './PriceChangeIndicator';
import { useAuth } from '../auth/AuthProvider';

interface CartEnvelope {
  id: string;
  name: string;
  items: CartItem[];
}

interface CartItem {
  id: string;
  part_number: string;
  name: string;
  price: number;
  quantity: number;
  delivery_days: number;
  price_changes?: {
    oldPrice: number;
    newPrice: number;
    oldDelivery: number;
    newDelivery: number;
  };
}

export function CartView() {
  const { user } = useAuth();
  const [envelopes, setEnvelopes] = useState<CartEnvelope[]>([]);
  const [newEnvelopeName, setNewEnvelopeName] = useState('');
  const [isCreatingEnvelope, setIsCreatingEnvelope] = useState(false);

  useEffect(() => {
    if (user) {
      loadCart();
    }
  }, [user]);

  const loadCart = async () => {
    const { data: cartData, error } = await supabase
      .from('cart_envelopes')
      .select(`
        id,
        name,
        cart_items (
          id,
          part_number,
          name,
          price,
          quantity,
          delivery_days
        )
      `)
      .eq('profile_id', user?.id);

    if (error) {
      console.error('Error loading cart:', error);
    } else {
      setEnvelopes(cartData || []);
    }
  };

  const createEnvelope = async () => {
    if (!newEnvelopeName.trim()) return;

    const { error } = await supabase
      .from('cart_envelopes')
      .insert([
        {
          profile_id: user?.id,
          name: newEnvelopeName.trim()
        }
      ]);

    if (error) {
      console.error('Error creating envelope:', error);
    } else {
      setNewEnvelopeName('');
      setIsCreatingEnvelope(false);
      loadCart();
    }
  };

  const removeFromCart = async (itemId: string) => {
    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('id', itemId);

    if (error) {
      console.error('Error removing item:', error);
    } else {
      loadCart();
    }
  };

  const updateQuantity = async (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) return;

    const { error } = await supabase
      .from('cart_items')
      .update({ quantity: newQuantity })
      .eq('id', itemId);

    if (error) {
      console.error('Error updating quantity:', error);
    } else {
      loadCart();
    }
  };

  const calculateEnvelopeTotal = (items: CartItem[]) => {
    return items.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-light">Корзина</h1>
        <button
          onClick={() => setIsCreatingEnvelope(true)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Новый конверт</span>
        </button>
      </div>

      {isCreatingEnvelope && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-900 p-6 rounded-lg w-full max-w-md">
            <h3 className="text-xl font-light mb-4">Создать новый конверт</h3>
            <input
              type="text"
              value={newEnvelopeName}
              onChange={(e) => setNewEnvelopeName(e.target.value)}
              placeholder="Название конверта"
              className="w-full px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 mb-4"
            />
            <div className="flex gap-4">
              <button
                onClick={createEnvelope}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                Создать
              </button>
              <button
                onClick={() => setIsCreatingEnvelope(false)}
                className="flex-1 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 px-4 py-2 rounded-lg transition-colors"
              >
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-8">
        {envelopes.map((envelope) => (
          <div
            key={envelope.id}
            className="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Folder className="w-6 h-6 text-blue-500" />
                <h2 className="text-xl font-medium">{envelope.name}</h2>
              </div>
              <span className="text-lg font-medium">
                {calculateEnvelopeTotal(envelope.items).toLocaleString('ru-RU')} ₽
              </span>
            </div>

            <div className="space-y-4">
              {envelope.items.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                >
                  <div className="flex-1">
                    <h3 className="font-medium">{item.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 part-number">
                      {item.part_number}
                    </p>
                    {item.price_changes && (
                      <PriceChangeIndicator changes={item.price_changes} />
                    )}
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="w-8 h-8 flex items-center justify-center bg-gray-200 dark:bg-gray-700 rounded-lg"
                      >
                        -
                      </button>
                      <span className="w-12 text-center">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="w-8 h-8 flex items-center justify-center bg-gray-200 dark:bg-gray-700 rounded-lg"
                      >
                        +
                      </button>
                    </div>
                    <span className="w-32 text-right">
                      {(item.price * item.quantity).toLocaleString('ru-RU')} ₽
                    </span>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}