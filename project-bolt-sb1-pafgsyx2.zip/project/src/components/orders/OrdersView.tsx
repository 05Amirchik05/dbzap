import React, { useState, useEffect } from 'react';
import { Package, Clock, Download, MapPin, Truck } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../auth/AuthProvider';

interface OrderItem {
  id: string;
  part_number: string;
  name: string;
  quantity: number;
  price_per_unit: number;
  delivery_days: number;
}

interface Order {
  id: string;
  status: string;
  delivery_type: string;
  delivery_address: string;
  total_amount: number;
  created_at: string;
  comment?: string;
  items: OrderItem[];
}

export function OrdersView() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (user) {
      loadOrders();
    }
  }, [user]);

  const loadOrders = async () => {
    const { data: ordersData, error: ordersError } = await supabase
      .from('orders')
      .select(`
        *,
        items:order_items(*)
      `)
      .eq('profile_id', user?.id)
      .order('created_at', { ascending: false });

    if (ordersError) {
      console.error('Error loading orders:', ordersError);
    } else {
      setOrders(ordersData || []);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'processing':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'shipped':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'delivered':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const getDeliveryIcon = (type: string) => {
    switch (type) {
      case 'pickup':
        return <MapPin className="w-5 h-5" />;
      case 'delivery':
        return <Truck className="w-5 h-5" />;
      default:
        return <Package className="w-5 h-5" />;
    }
  };

  const downloadInvoice = async (order: Order) => {
    // Implement invoice download logic
    console.log('Downloading invoice for order:', order.id);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex items-center gap-3 mb-8">
        <Package className="w-6 h-6" />
        <h1 className="text-2xl font-light">Мои заказы</h1>
      </div>

      <div className="space-y-8">
        {orders.map((order) => (
          <div
            key={order.id}
            className="bg-white dark:bg-gray-900 rounded-lg shadow-lg overflow-hidden"
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {new Date(order.created_at).toLocaleDateString('ru-RU')}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Заказ №{order.id.slice(0, 8)}
                  </p>
                </div>
                <button
                  onClick={() => downloadInvoice(order)}
                  className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
                >
                  <Download className="w-5 h-5" />
                  <span>Накладная</span>
                </button>
              </div>

              <div className="space-y-4">
                {order.items.map((item) => (
                  <div
                    key={item.id}
                    className="flex justify-between items-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                  >
                    <div>
                      <h3 className="font-medium">{item.name}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 part-number">
                        {item.part_number}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">
                        {(item.price_per_unit * item.quantity).toLocaleString('ru-RU')} ₽
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {item.quantity} шт. × {item.price_per_unit.toLocaleString('ru-RU')} ₽
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400">
                    {getDeliveryIcon(order.delivery_type)}
                    <span>{order.delivery_address}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Итого</p>
                    <p className="text-xl font-medium">
                      {order.total_amount.toLocaleString('ru-RU')} ₽
                    </p>
                  </div>
                </div>
                {order.comment && (
                  <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">
                    Комментарий: {order.comment}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}

        {orders.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            <Package className="w-12 h-12 mx-auto mb-4 stroke-1" />
            <p>У вас пока нет заказов</p>
          </div>
        )}
      </div>
    </div>
  );
}