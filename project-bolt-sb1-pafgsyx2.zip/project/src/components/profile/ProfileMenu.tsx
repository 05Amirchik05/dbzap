import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthProvider';
import {
  User,
  Car,
  Heart,
  ShoppingCart,
  Clock,
  Wallet,
  LogOut,
  Settings
} from 'lucide-react';

export function ProfileMenu() {
  const { user, signOut } = useAuth();

  if (!user) return null;

  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-4 w-64">
      <div className="space-y-2">
        <Link
          to="/profile"
          className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
        >
          <User className="w-5 h-5" />
          <span>Профиль</span>
        </Link>
        
        <Link
          to="/garage"
          className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
        >
          <Car className="w-5 h-5" />
          <span>Гараж</span>
        </Link>
        
        <Link
          to="/favorites"
          className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
        >
          <Heart className="w-5 h-5" />
          <span>Избранное</span>
        </Link>
        
        <Link
          to="/cart"
          className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
        >
          <ShoppingCart className="w-5 h-5" />
          <span>Корзина</span>
        </Link>
        
        <Link
          to="/orders"
          className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
        >
          <Clock className="w-5 h-5" />
          <span>Заказы</span>
        </Link>
        
        <Link
          to="/balance"
          className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
        >
          <Wallet className="w-5 h-5" />
          <span>Баланс</span>
        </Link>
        
        <Link
          to="/settings"
          className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
        >
          <Settings className="w-5 h-5" />
          <span>Настройки</span>
        </Link>
        
        <button
          onClick={() => signOut()}
          className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors w-full text-left text-red-500"
        >
          <LogOut className="w-5 h-5" />
          <span>Выйти</span>
        </button>
      </div>
    </div>
  );
}