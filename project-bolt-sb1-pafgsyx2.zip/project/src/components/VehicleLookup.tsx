import React, { useState } from 'react';
import { Search, Loader2 } from 'lucide-react';

export function VehicleLookup() {
  const [regNumber, setRegNumber] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [vehicleInfo, setVehicleInfo] = useState(null);

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regNumber.trim()) return;

    setIsLoading(true);
    // Here you would integrate with a vehicle database API
    // For now, we'll simulate a loading state
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
      <h2 className="text-xl font-light mb-4">Поиск по госномеру</h2>
      <form onSubmit={handleLookup}>
        <div className="relative">
          <input
            type="text"
            value={regNumber}
            onChange={(e) => setRegNumber(e.target.value)}
            placeholder="Введите госномер автомобиля"
            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 pl-12 text-white placeholder-gray-500 focus:outline-none focus:border-gray-600"
          />
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 w-5 h-5" />
          {isLoading && (
            <Loader2 className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 w-5 h-5 animate-spin" />
          )}
        </div>
      </form>
    </div>
  );
}