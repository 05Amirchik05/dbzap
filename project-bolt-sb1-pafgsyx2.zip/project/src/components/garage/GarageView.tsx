import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Plus, Trash2, Edit } from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';

interface Vehicle {
  id: string;
  vin: string;
  nickname: string;
  make: string;
  model: string;
  year: number;
}

export function GarageView() {
  const { user } = useAuth();
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [isAddingVehicle, setIsAddingVehicle] = useState(false);
  const [newVehicle, setNewVehicle] = useState({
    vin: '',
    nickname: '',
    make: '',
    model: '',
    year: new Date().getFullYear()
  });

  useEffect(() => {
    if (user) {
      loadVehicles();
    }
  }, [user]);

  const loadVehicles = async () => {
    const { data, error } = await supabase
      .from('garages')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading vehicles:', error);
    } else {
      setVehicles(data || []);
    }
  };

  const handleAddVehicle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const { error } = await supabase
      .from('garages')
      .insert([{ ...newVehicle, profile_id: user.id }]);

    if (error) {
      console.error('Error adding vehicle:', error);
    } else {
      setIsAddingVehicle(false);
      setNewVehicle({ vin: '', nickname: '', make: '', model: '', year: new Date().getFullYear() });
      loadVehicles();
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-light">Мой гараж</h2>
        <button
          onClick={() => setIsAddingVehicle(true)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Добавить автомобиль</span>
        </button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {vehicles.map((vehicle) => (
          <div
            key={vehicle.id}
            className="bg-white dark:bg-gray-900 rounded-lg p-6 shadow-lg"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-medium">{vehicle.nickname || 'Без названия'}</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  {vehicle.make} {vehicle.model} {vehicle.year}
                </p>
              </div>
              <div className="flex gap-2">
                <button className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                  <Edit className="w-5 h-5" />
                </button>
                <button className="text-red-500 hover:text-red-700">
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              VIN: <span className="font-mono part-number">{vehicle.vin}</span>
            </p>
          </div>
        ))}
      </div>

      {isAddingVehicle && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
          <div className="bg-white dark:bg-gray-900 p-8 rounded-lg w-full max-w-md">
            <h3 className="text-xl font-light mb-6">Добавить автомобиль</h3>
            <form onSubmit={handleAddVehicle} className="space-y-4">
              <input
                type="text"
                value={newVehicle.vin}
                onChange={(e) => setNewVehicle({ ...newVehicle, vin: e.target.value })}
                placeholder="VIN номер"
                className="w-full px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700"
                required
              />
              <input
                type="text"
                value={newVehicle.nickname}
                onChange={(e) => setNewVehicle({ ...newVehicle, nickname: e.target.value })}
                placeholder="Название (необязательно)"
                className="w-full px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700"
              />
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  value={newVehicle.make}
                  onChange={(e) => setNewVehicle({ ...newVehicle, make: e.target.value })}
                  placeholder="Марка"
                  className="w-full px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700"
                  required
                />
                <input
                  type="text"
                  value={newVehicle.model}
                  onChange={(e) => setNewVehicle({ ...newVehicle, model: e.target.value })}
                  placeholder="Модель"
                  className="w-full px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700"
                  required
                />
              </div>
              <input
                type="number"
                value={newVehicle.year}
                onChange={(e) => setNewVehicle({ ...newVehicle, year: parseInt(e.target.value) })}
                placeholder="Год выпуска"
                className="w-full px-4 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700"
                required
              />
              <div className="flex gap-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                >
                  Добавить
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddingVehicle(false)}
                  className="flex-1 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-medium py-2 px-4 rounded-lg transition-colors"
                >
                  Отмена
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}