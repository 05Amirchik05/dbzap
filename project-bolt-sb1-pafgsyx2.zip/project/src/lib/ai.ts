import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: 'your-api-key', // Replace with your actual API key
  dangerouslyAllowBrowser: true
});

export async function searchParts(query: string) {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are an expert auto parts specialist. Analyze the user's query and provide detailed information about the requested auto parts. Return the results in a structured format with part name, description, compatibility, price range, and availability."
        },
        {
          role: "user",
          content: query
        }
      ],
      temperature: 0.7,
    });

    // Parse the AI response and structure it
    const response = completion.choices[0].message.content;
    // This is a simplified example - you would need to properly parse the AI response
    return [{
      partName: "Example Part",
      description: "Part description based on AI response",
      compatibility: "Compatible vehicles",
      price: "$100-150",
      availability: "In Stock"
    }];
  } catch (error) {
    console.error('Error searching parts:', error);
    throw error;
  }
}